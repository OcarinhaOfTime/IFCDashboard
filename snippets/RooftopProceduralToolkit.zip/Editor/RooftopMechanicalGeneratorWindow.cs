#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using OrientationMode = RoofFacetDetector.OrientationMode;
using RoofFacet = RoofFacetDetector.Facet;
using FacetProjection = RoofFacetDetector.Projection;

/// <summary>
/// Generates a deterministic, roof-aligned network of low-poly ducts,
/// pipes, supports, vents, junction boxes, and terminal equipment.
///
/// The tool is deliberately an editor generator: the resulting objects are
/// ordinary scene geometry and require no procedural runtime code in WebGL.
/// </summary>
public sealed class RooftopMechanicalGeneratorWindow : EditorWindow
{
    private enum TerminalType
    {
        AirHandlingUnit,
        FanHousing,
        VentCluster,
        PipeManifold
    }

    private sealed class PlannedSegment
    {
        public int facetIndex;
        public int depth;
        public int index;
        public Vector2 center;
        public Vector2 direction;
        public float length;
        public float width;
        public float height;
        public bool primary;
        public bool addPipeBundle;
        public readonly List<Vector2> childStarts =
            new List<Vector2>();

        public Vector2 Start
        {
            get { return center - direction * length * 0.5f; }
        }

        public Vector2 End
        {
            get { return center + direction * length * 0.5f; }
        }
    }

    private sealed class PlannedTerminal
    {
        public int facetIndex;
        public Vector2 position;
        public Vector2 direction;
        public TerminalType type;
        public Vector3 size;
        public float rotationJitter;
    }

    private sealed class FacetPlan
    {
        public int facetIndex;
        public FacetProjection projection;
        public readonly List<PlannedSegment> segments =
            new List<PlannedSegment>();
        public readonly List<PlannedTerminal> terminals =
            new List<PlannedTerminal>();
        public Vector3[] boundaryLines = Array.Empty<Vector3>();
        public Vector3[] segmentLines = Array.Empty<Vector3>();
        public Vector3[] terminalLines = Array.Empty<Vector3>();
    }

    [Header("References")]
    [SerializeField] private GameObject siteRoot;
    [SerializeField] private GameObject buildingRoot;
    [SerializeField] private Transform exclusionRoot;

    [Header("Materials")]
    [SerializeField] private Material ductMaterial;
    [SerializeField] private Material pipeMaterial;
    [SerializeField] private Material equipmentMaterial;
    [SerializeField] private Material supportMaterial;

    [Header("Roof Detection")]
    [SerializeField, Range(0f, 0.95f)]
    private float minimumRelativeHeight = 0.55f;

    [SerializeField, Min(0.1f)]
    private float roofSearchDepth = 6f;

    [SerializeField, Range(1f, 80f)]
    private float maximumRoofSlope = 55f;

    [SerializeField, Range(0.1f, 20f)]
    private float normalMergeTolerance = 4f;

    [SerializeField, Min(0.001f)]
    private float planeMergeTolerance = 0.18f;

    [SerializeField, Min(0.001f)]
    private float minimumTriangleArea = 0.02f;

    [SerializeField, Min(0.01f)]
    private float minimumFacetArea = 4f;

    [Header("Roof Orientation")]
    [SerializeField]
    private OrientationMode orientationMode =
        OrientationMode.PrincipalAxis;

    [SerializeField]
    private float orientationOffset;

    [SerializeField]
    private bool snapPrincipalAxisToBoundary = true;

    [SerializeField, Range(0f, 45f)]
    private float boundarySnapTolerance = 14f;

    [SerializeField, Range(0f, 1f)]
    private float pcaAmbiguityThreshold = 0.08f;

    [Header("Network")]
    [SerializeField] private int seed = 3817;

    [SerializeField, Range(1, 4)]
    private int primarySpineCount = 1;

    [SerializeField, Range(0, 4)]
    private int maximumRecursionDepth = 2;

    [SerializeField, Range(0f, 1f)]
    private float branchProbability = 0.48f;

    [SerializeField, Min(1f)]
    private float branchSpacing = 7f;

    [SerializeField, Range(0f, 25f)]
    private float branchPositionJitter = 1.2f;

    [SerializeField, Range(45f, 135f)]
    private float branchAngle = 90f;

    [SerializeField, Range(0f, 20f)]
    private float branchAngleJitter = 3f;

    [SerializeField, Min(0.5f)]
    private float minimumBranchLength = 3f;

    [SerializeField, Range(0.2f, 0.95f)]
    private float lengthDecay = 0.62f;

    [SerializeField, Range(0.2f, 0.95f)]
    private float widthDecay = 0.68f;

    [SerializeField, Min(0.1f)]
    private float primaryDuctWidth = 1.25f;

    [SerializeField, Min(0.1f)]
    private float primaryDuctHeight = 0.9f;

    [SerializeField, Min(0f)]
    private float roofEdgePadding = 1f;

    [SerializeField, Min(0f)]
    private float roofClearance = 0.12f;

    [SerializeField, Min(0f)]
    private float objectSeparation = 0.18f;

    [Header("Equipment")]
    [SerializeField, Range(0f, 1f)]
    private float terminalEquipmentRate = 0.72f;

    [SerializeField, Range(0f, 1f)]
    private float junctionBoxRate = 0.62f;

    [SerializeField, Range(0f, 1f)]
    private float pipeBundleRate = 0.38f;

    [SerializeField, Range(0f, 1f)]
    private float ventRate = 0.22f;

    [SerializeField, Range(1, 6)]
    private int minimumPipeCount = 2;

    [SerializeField, Range(1, 8)]
    private int maximumPipeCount = 4;

    [SerializeField, Min(0.02f)]
    private float pipeRadius = 0.12f;

    [SerializeField, Min(0.02f)]
    private float pipeSpacing = 0.18f;

    [SerializeField] private Vector2 equipmentLengthRange =
        new Vector2(2.4f, 5.2f);

    [SerializeField] private Vector2 equipmentWidthRange =
        new Vector2(1.6f, 3.4f);

    [SerializeField] private Vector2 equipmentHeightRange =
        new Vector2(0.9f, 2.1f);

    [Header("Supports")]
    [SerializeField] private bool generateSupports = true;

    [SerializeField, Min(0.5f)]
    private float supportSpacing = 3f;

    [SerializeField, Min(0.02f)]
    private float supportThickness = 0.12f;

    [SerializeField, Min(0.02f)]
    private float supportHeight = 0.18f;

    [Header("Output")]
    [SerializeField] private string outputRootName =
        "rooftop_mechanical";

    [SerializeField] private string buildingFolderName = "";
    [SerializeField] private bool replaceExisting = true;
    [SerializeField] private bool markGeneratedStatic = true;
    [SerializeField] private bool removePrimitiveColliders = true;

    [Header("Preview")]
    [SerializeField] private bool showDetectedFacets = true;
    [SerializeField] private bool showFacetLabels = true;
    [SerializeField] private bool showNetworkPreview = true;
    [SerializeField] private bool showTerminalPreview = true;
    [SerializeField] private bool autoRebuildPreview = false;

    private readonly List<RoofFacet> facets =
        new List<RoofFacet>();

    private readonly List<FacetPlan> plans =
        new List<FacetPlan>();

    private readonly List<Bounds> exclusionBounds =
        new List<Bounds>();

    private Vector2 scroll;
    private Bounds buildingBounds;
    private int scannedTriangles;
    private int acceptedTriangles;
    private string status =
        "Assign a building and detect its roof facets.";
    private string previewStatus = "No procedural plan has been built.";
    private bool previewDirty = true;

    [MenuItem("Tools/IFC Dashboard/Rooftop Mechanical Generator")]
    public static void Open()
    {
        RooftopMechanicalGeneratorWindow window =
            GetWindow<RooftopMechanicalGeneratorWindow>(
                "Rooftop Mechanical"
            );
        window.minSize = new Vector2(420f, 700f);
        window.Show();
    }

    private void OnEnable()
    {
        SceneView.duringSceneGui += DrawScenePreview;
    }

    private void OnDisable()
    {
        SceneView.duringSceneGui -= DrawScenePreview;
    }

    private void OnGUI()
    {
        EditorGUI.BeginChangeCheck();

        scroll = EditorGUILayout.BeginScrollView(scroll);

        DrawReferences();
        EditorGUILayout.Space(6f);
        DrawDetection();
        EditorGUILayout.Space(6f);
        DrawFacets();
        EditorGUILayout.Space(6f);
        DrawNetwork();
        EditorGUILayout.Space(6f);
        DrawEquipment();
        EditorGUILayout.Space(6f);
        DrawOutput();
        EditorGUILayout.Space(8f);
        DrawActions();

        EditorGUILayout.EndScrollView();

        if (EditorGUI.EndChangeCheck())
        {
            previewDirty = true;
            if (autoRebuildPreview && facets.Count > 0)
            {
                BuildPreviewPlan();
            }
            SceneView.RepaintAll();
        }
    }

    private void DrawReferences()
    {
        EditorGUILayout.LabelField(
            "1. References",
            EditorStyles.boldLabel
        );

        siteRoot = (GameObject)EditorGUILayout.ObjectField(
            "Site Root",
            siteRoot,
            typeof(GameObject),
            true
        );

        buildingRoot = (GameObject)EditorGUILayout.ObjectField(
            "Building Root",
            buildingRoot,
            typeof(GameObject),
            true
        );

        exclusionRoot = (Transform)EditorGUILayout.ObjectField(
            new GUIContent(
                "Exclusion Root",
                "Optional hierarchy such as roof_panels. Generated " +
                "mechanical geometry avoids its renderer bounds."
            ),
            exclusionRoot,
            typeof(Transform),
            true
        );

        ductMaterial = (Material)EditorGUILayout.ObjectField(
            "Duct Material",
            ductMaterial,
            typeof(Material),
            false
        );
        pipeMaterial = (Material)EditorGUILayout.ObjectField(
            "Pipe Material",
            pipeMaterial,
            typeof(Material),
            false
        );
        equipmentMaterial = (Material)EditorGUILayout.ObjectField(
            "Equipment Material",
            equipmentMaterial,
            typeof(Material),
            false
        );
        supportMaterial = (Material)EditorGUILayout.ObjectField(
            "Support Material",
            supportMaterial,
            typeof(Material),
            false
        );

        if (
            buildingRoot != null &&
            siteRoot == null &&
            GUILayout.Button("Use Building Scene Root As Site Root")
        )
        {
            siteRoot = FindLikelySiteRoot(buildingRoot.transform);
        }
    }

    private void DrawDetection()
    {
        EditorGUILayout.LabelField(
            "2. Roof Detection",
            EditorStyles.boldLabel
        );

        minimumRelativeHeight = EditorGUILayout.Slider(
            "Minimum Relative Height",
            minimumRelativeHeight,
            0f,
            0.95f
        );
        roofSearchDepth = EditorGUILayout.FloatField(
            "Roof Search Depth",
            roofSearchDepth
        );
        maximumRoofSlope = EditorGUILayout.Slider(
            "Maximum Roof Slope",
            maximumRoofSlope,
            1f,
            80f
        );
        normalMergeTolerance = EditorGUILayout.Slider(
            "Normal Merge Tolerance",
            normalMergeTolerance,
            0.1f,
            20f
        );
        planeMergeTolerance = EditorGUILayout.FloatField(
            "Plane Merge Tolerance",
            planeMergeTolerance
        );
        minimumTriangleArea = EditorGUILayout.FloatField(
            "Minimum Triangle Area",
            minimumTriangleArea
        );
        minimumFacetArea = EditorGUILayout.FloatField(
            "Minimum Facet Area",
            minimumFacetArea
        );

        orientationMode =
            (OrientationMode)EditorGUILayout.EnumPopup(
                "Orientation Mode",
                orientationMode
            );
        orientationOffset = EditorGUILayout.Slider(
            "Orientation Offset",
            orientationOffset,
            -180f,
            180f
        );
        snapPrincipalAxisToBoundary = EditorGUILayout.Toggle(
            "Snap PCA To Roof Edge",
            snapPrincipalAxisToBoundary
        );

        if (snapPrincipalAxisToBoundary)
        {
            boundarySnapTolerance = EditorGUILayout.Slider(
                "Boundary Snap Tolerance",
                boundarySnapTolerance,
                0f,
                45f
            );
        }

        pcaAmbiguityThreshold = EditorGUILayout.Slider(
            "PCA Ambiguity Threshold",
            pcaAmbiguityThreshold,
            0f,
            1f
        );

        if (GUILayout.Button("Detect Roof Facets"))
        {
            DetectRoofs();
        }

        EditorGUILayout.HelpBox(status, MessageType.Info);
    }

    private void DrawFacets()
    {
        EditorGUILayout.LabelField(
            "3. Detected Roof Facets",
            EditorStyles.boldLabel
        );

        showDetectedFacets = EditorGUILayout.Toggle(
            "Show Detected Facets",
            showDetectedFacets
        );
        showFacetLabels = EditorGUILayout.Toggle(
            "Show Facet Labels",
            showFacetLabels
        );

        if (facets.Count == 0)
        {
            EditorGUILayout.HelpBox(
                "Run roof detection first.",
                MessageType.None
            );
            return;
        }

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Enable All"))
        {
            foreach (RoofFacet facet in facets)
            {
                facet.enabled = true;
            }
            previewDirty = true;
        }
        if (GUILayout.Button("Disable All"))
        {
            foreach (RoofFacet facet in facets)
            {
                facet.enabled = false;
            }
            previewDirty = true;
        }
        EditorGUILayout.EndHorizontal();

        for (int index = 0; index < facets.Count; index++)
        {
            RoofFacet facet = facets[index];
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            facet.enabled = EditorGUILayout.ToggleLeft(
                string.Format(
                    "Facet {0:00}    Area {1:F1} m²    Slope {2:F1}°",
                    index,
                    facet.area,
                    facet.Slope
                ),
                facet.enabled
            );
            EditorGUILayout.LabelField(
                string.Format(
                    "Height {0:F2}–{1:F2}   PCA confidence {2:F2}",
                    facet.minY,
                    facet.maxY,
                    facet.orientationConfidence
                ),
                EditorStyles.miniLabel
            );
            EditorGUILayout.EndVertical();
        }
    }

    private void DrawNetwork()
    {
        EditorGUILayout.LabelField(
            "4. Recursive Network",
            EditorStyles.boldLabel
        );

        seed = EditorGUILayout.IntField("Seed", seed);
        primarySpineCount = EditorGUILayout.IntSlider(
            "Primary Spine Count",
            primarySpineCount,
            1,
            4
        );
        maximumRecursionDepth = EditorGUILayout.IntSlider(
            "Maximum Recursion Depth",
            maximumRecursionDepth,
            0,
            4
        );
        branchProbability = EditorGUILayout.Slider(
            "Branch Probability",
            branchProbability,
            0f,
            1f
        );
        branchSpacing = EditorGUILayout.FloatField(
            "Branch Spacing",
            branchSpacing
        );
        branchPositionJitter = EditorGUILayout.Slider(
            "Branch Position Jitter",
            branchPositionJitter,
            0f,
            5f
        );
        branchAngle = EditorGUILayout.Slider(
            "Branch Angle",
            branchAngle,
            45f,
            135f
        );
        branchAngleJitter = EditorGUILayout.Slider(
            "Branch Angle Jitter",
            branchAngleJitter,
            0f,
            20f
        );
        minimumBranchLength = EditorGUILayout.FloatField(
            "Minimum Branch Length",
            minimumBranchLength
        );
        lengthDecay = EditorGUILayout.Slider(
            "Length Decay",
            lengthDecay,
            0.2f,
            0.95f
        );
        widthDecay = EditorGUILayout.Slider(
            "Width Decay",
            widthDecay,
            0.2f,
            0.95f
        );
        primaryDuctWidth = EditorGUILayout.FloatField(
            "Primary Duct Width",
            primaryDuctWidth
        );
        primaryDuctHeight = EditorGUILayout.FloatField(
            "Primary Duct Height",
            primaryDuctHeight
        );
        roofEdgePadding = EditorGUILayout.FloatField(
            "Roof Edge Padding",
            roofEdgePadding
        );
        roofClearance = EditorGUILayout.FloatField(
            "Roof Clearance",
            roofClearance
        );
        objectSeparation = EditorGUILayout.FloatField(
            "Object Separation",
            objectSeparation
        );
    }

    private void DrawEquipment()
    {
        EditorGUILayout.LabelField(
            "5. Equipment and Dressing",
            EditorStyles.boldLabel
        );

        terminalEquipmentRate = EditorGUILayout.Slider(
            "Terminal Equipment Rate",
            terminalEquipmentRate,
            0f,
            1f
        );
        junctionBoxRate = EditorGUILayout.Slider(
            "Junction Box Rate",
            junctionBoxRate,
            0f,
            1f
        );
        pipeBundleRate = EditorGUILayout.Slider(
            "Pipe Bundle Rate",
            pipeBundleRate,
            0f,
            1f
        );
        ventRate = EditorGUILayout.Slider(
            "Vent Rate",
            ventRate,
            0f,
            1f
        );
        minimumPipeCount = EditorGUILayout.IntSlider(
            "Minimum Pipe Count",
            minimumPipeCount,
            1,
            6
        );
        maximumPipeCount = EditorGUILayout.IntSlider(
            "Maximum Pipe Count",
            maximumPipeCount,
            minimumPipeCount,
            8
        );
        pipeRadius = EditorGUILayout.FloatField(
            "Pipe Radius",
            pipeRadius
        );
        pipeSpacing = EditorGUILayout.FloatField(
            "Pipe Spacing",
            pipeSpacing
        );
        equipmentLengthRange = EditorGUILayout.Vector2Field(
            "Equipment Length Range",
            equipmentLengthRange
        );
        equipmentWidthRange = EditorGUILayout.Vector2Field(
            "Equipment Width Range",
            equipmentWidthRange
        );
        equipmentHeightRange = EditorGUILayout.Vector2Field(
            "Equipment Height Range",
            equipmentHeightRange
        );

        generateSupports = EditorGUILayout.Toggle(
            "Generate Supports",
            generateSupports
        );

        if (generateSupports)
        {
            supportSpacing = EditorGUILayout.FloatField(
                "Support Spacing",
                supportSpacing
            );
            supportThickness = EditorGUILayout.FloatField(
                "Support Thickness",
                supportThickness
            );
            supportHeight = EditorGUILayout.FloatField(
                "Support Height",
                supportHeight
            );
        }
    }

    private void DrawOutput()
    {
        EditorGUILayout.LabelField(
            "6. Output and Preview",
            EditorStyles.boldLabel
        );

        outputRootName = EditorGUILayout.TextField(
            "Output Root Name",
            outputRootName
        );
        buildingFolderName = EditorGUILayout.TextField(
            "Building Folder Name",
            buildingFolderName
        );
        replaceExisting = EditorGUILayout.Toggle(
            "Replace Existing",
            replaceExisting
        );
        markGeneratedStatic = EditorGUILayout.Toggle(
            "Mark Generated Static",
            markGeneratedStatic
        );
        removePrimitiveColliders = EditorGUILayout.Toggle(
            "Remove Primitive Colliders",
            removePrimitiveColliders
        );

        showNetworkPreview = EditorGUILayout.Toggle(
            "Show Network Preview",
            showNetworkPreview
        );
        showTerminalPreview = EditorGUILayout.Toggle(
            "Show Terminal Preview",
            showTerminalPreview
        );
        autoRebuildPreview = EditorGUILayout.Toggle(
            "Auto Rebuild Preview",
            autoRebuildPreview
        );

        EditorGUILayout.HelpBox(previewStatus, MessageType.None);
    }

    private void DrawActions()
    {
        GUI.enabled = facets.Count > 0;

        if (GUILayout.Button("Build / Refresh Preview", GUILayout.Height(28f)))
        {
            BuildPreviewPlan();
        }

        GUI.backgroundColor = new Color(0.45f, 0.85f, 0.45f);
        if (GUILayout.Button("Generate Rooftop Mechanical", GUILayout.Height(34f)))
        {
            GenerateMechanicalGeometry();
        }
        GUI.backgroundColor = Color.white;

        GUI.enabled = true;

        if (GUILayout.Button("Clear Generated Mechanical"))
        {
            ClearGeneratedMechanical();
        }
    }

    private void DetectRoofs()
    {
        facets.Clear();
        plans.Clear();

        RoofFacetDetector.DetectionSettings settings =
            new RoofFacetDetector.DetectionSettings
            {
                minimumRelativeHeight = minimumRelativeHeight,
                roofSearchDepth = roofSearchDepth,
                maximumRoofSlope = maximumRoofSlope,
                normalMergeTolerance = normalMergeTolerance,
                planeMergeTolerance = planeMergeTolerance,
                minimumTriangleArea = minimumTriangleArea,
                minimumFacetArea = minimumFacetArea,
                splitDisconnectedFacets = true
            };

        RoofFacetDetector.DetectionResult result =
            RoofFacetDetector.Detect(buildingRoot, settings);

        buildingBounds = result.buildingBounds;
        scannedTriangles = result.scannedTriangles;
        acceptedTriangles = result.acceptedTriangles;
        status = result.status;
        facets.AddRange(result.facets);
        previewDirty = true;

        if (result.succeeded)
        {
            BuildPreviewPlan();
            LogDetectedFacets();
        }
        else
        {
            previewStatus = "No procedural plan is available.";
        }

        SceneView.RepaintAll();
        Repaint();
    }

    private void BuildPreviewPlan()
    {
        plans.Clear();
        RebuildExclusionBounds();

        int totalSegments = 0;
        int totalTerminals = 0;

        for (int facetIndex = 0;
            facetIndex < facets.Count;
            facetIndex++)
        {
            RoofFacet facet = facets[facetIndex];
            if (!facet.enabled)
            {
                continue;
            }

            FacetProjection projection =
                ResolveFacetProjection(facet);

            FacetPlan plan = new FacetPlan
            {
                facetIndex = facetIndex,
                projection = projection
            };

            BuildFacetPlan(plan, facet);
            BuildPreviewLines(plan, facet);

            if (plan.segments.Count > 0)
            {
                plans.Add(plan);
                totalSegments += plan.segments.Count;
                totalTerminals += plan.terminals.Count;
            }
        }

        previewDirty = false;
        previewStatus = string.Format(
            "Planned {0} duct segments and {1} terminal units " +
            "across {2} roof facets.",
            totalSegments,
            totalTerminals,
            plans.Count
        );

        SceneView.RepaintAll();
        Repaint();
    }

    private void BuildFacetPlan(
        FacetPlan plan,
        RoofFacet facet)
    {
        FacetProjection projection = plan.projection;
        Vector2 size = projection.max - projection.min;

        float availableLength =
            size.x - roofEdgePadding * 2f;
        float availableWidth =
            size.y - roofEdgePadding * 2f;

        if (
            availableLength < minimumBranchLength ||
            availableWidth < primaryDuctWidth
        )
        {
            return;
        }

        System.Random random = new System.Random(
            CombineSeed(seed, plan.facetIndex)
        );

        int spineCount = Mathf.Clamp(
            primarySpineCount,
            1,
            Mathf.Max(
                1,
                Mathf.FloorToInt(
                    availableWidth /
                    Mathf.Max(primaryDuctWidth * 2.2f, 0.1f)
                )
            )
        );

        float laneSpacing = availableWidth / (spineCount + 1f);

        for (int spineIndex = 0;
            spineIndex < spineCount;
            spineIndex++)
        {
            float v = projection.min.y +
                roofEdgePadding +
                laneSpacing * (spineIndex + 1f);

            float runCenterU;
            float runLength;

            if (!TryFindLongestHorizontalRun(
                projection,
                v,
                primaryDuctWidth + objectSeparation,
                out runCenterU,
                out runLength
            ))
            {
                continue;
            }

            float randomInset = Range(
                random,
                0f,
                Mathf.Min(runLength * 0.12f, 4f)
            );

            float length = runLength - randomInset;
            Vector2 center = new Vector2(runCenterU, v);

            PlannedSegment primary = new PlannedSegment
            {
                facetIndex = plan.facetIndex,
                depth = 0,
                index = plan.segments.Count,
                center = center,
                direction = Vector2.right,
                length = length,
                width = primaryDuctWidth,
                height = primaryDuctHeight,
                primary = true,
                addPipeBundle = random.NextDouble() < pipeBundleRate
            };

            if (!CanPlaceSegment(plan, primary))
            {
                continue;
            }

            plan.segments.Add(primary);
            BuildBranches(plan, primary, random, 1);

            if (random.NextDouble() < terminalEquipmentRate)
            {
                TryAddTerminal(
                    plan,
                    primary.End,
                    primary.direction,
                    random
                );
            }
        }
    }

    private bool TryFindLongestHorizontalRun(
        FacetProjection projection,
        float v,
        float width,
        out float centerU,
        out float length)
    {
        centerU = 0f;
        length = 0f;

        float minimumU = projection.min.x + roofEdgePadding;
        float maximumU = projection.max.x - roofEdgePadding;

        if (maximumU <= minimumU)
        {
            return false;
        }

        float sampleStep = Mathf.Max(0.35f, width * 0.45f);
        bool insideRun = false;
        float currentStart = minimumU;
        float bestStart = minimumU;
        float bestEnd = minimumU;

        for (float u = minimumU;
            u <= maximumU + sampleStep * 0.5f;
            u += sampleStep)
        {
            float sampledU = Mathf.Min(u, maximumU);
            bool valid = RoofFacetDetector.FootprintFits(
                projection,
                new Vector2(sampledU, v),
                sampleStep * 0.9f,
                width,
                3
            );

            if (valid && !insideRun)
            {
                insideRun = true;
                currentStart = sampledU;
            }

            bool closesRun =
                (!valid && insideRun) ||
                (insideRun && sampledU >= maximumU - 0.0001f);

            if (!closesRun)
            {
                continue;
            }

            float currentEnd = valid
                ? sampledU
                : Mathf.Max(currentStart, sampledU - sampleStep);

            if (currentEnd - currentStart > bestEnd - bestStart)
            {
                bestStart = currentStart;
                bestEnd = currentEnd;
            }

            insideRun = false;
        }

        length = bestEnd - bestStart;
        centerU = (bestStart + bestEnd) * 0.5f;

        return length >= minimumBranchLength;
    }

    private void BuildBranches(
        FacetPlan plan,
        PlannedSegment parent,
        System.Random random,
        int depth)
    {
        if (depth > maximumRecursionDepth)
        {
            return;
        }

        float usableLength = Mathf.Max(
            0f,
            parent.length - branchSpacing
        );

        int candidateCount = Mathf.Max(
            1,
            Mathf.FloorToInt(
                usableLength /
                Mathf.Max(branchSpacing, 0.5f)
            )
        );

        for (int candidate = 0;
            candidate < candidateCount;
            candidate++)
        {
            if (random.NextDouble() > branchProbability)
            {
                continue;
            }

            float fraction = (candidate + 1f) /
                (candidateCount + 1f);

            float along = Mathf.Lerp(
                -parent.length * 0.5f + branchSpacing * 0.5f,
                parent.length * 0.5f - branchSpacing * 0.5f,
                fraction
            );

            along += Range(
                random,
                -branchPositionJitter,
                branchPositionJitter
            );

            Vector2 branchStart =
                parent.center + parent.direction * along;

            float side = random.NextDouble() < 0.5 ? -1f : 1f;
            float resolvedAngle =
                side * (
                    branchAngle +
                    Range(
                        random,
                        -branchAngleJitter,
                        branchAngleJitter
                    )
                );

            Vector2 direction = Rotate2D(
                parent.direction,
                resolvedAngle
            ).normalized;

            float desiredLength = Mathf.Max(
                minimumBranchLength,
                parent.length * lengthDecay *
                    Range(random, 0.42f, 0.82f)
            );

            float width = Mathf.Max(
                0.18f,
                parent.width * widthDecay
            );

            float height = Mathf.Max(
                0.18f,
                parent.height * widthDecay
            );

            float maximumLength = FindMaximumBranchLength(
                plan,
                branchStart,
                direction,
                width,
                desiredLength
            );

            if (maximumLength < minimumBranchLength)
            {
                continue;
            }

            float length = Mathf.Min(
                desiredLength,
                maximumLength
            );

            Vector2 center =
                branchStart + direction * length * 0.5f;

            PlannedSegment branch = new PlannedSegment
            {
                facetIndex = plan.facetIndex,
                depth = depth,
                index = plan.segments.Count,
                center = center,
                direction = direction,
                length = length,
                width = width,
                height = height,
                primary = false,
                addPipeBundle = random.NextDouble() <
                    pipeBundleRate * 0.55f
            };

            if (!CanPlaceSegment(plan, branch))
            {
                continue;
            }

            parent.childStarts.Add(branchStart);
            plan.segments.Add(branch);

            BuildBranches(plan, branch, random, depth + 1);

            if (random.NextDouble() < terminalEquipmentRate)
            {
                TryAddTerminal(
                    plan,
                    branch.End,
                    branch.direction,
                    random
                );
            }
        }
    }

    private float FindMaximumBranchLength(
        FacetPlan plan,
        Vector2 start,
        Vector2 direction,
        float width,
        float desiredLength)
    {
        float step = Mathf.Max(0.5f, width * 0.75f);
        float acceptedLength = 0f;

        for (float length = minimumBranchLength;
            length <= desiredLength + 0.001f;
            length += step)
        {
            PlannedSegment probe = new PlannedSegment
            {
                facetIndex = plan.facetIndex,
                center = start + direction * length * 0.5f,
                direction = direction,
                length = length,
                width = width,
                height = primaryDuctHeight
            };

            if (!CanPlaceSegment(plan, probe, false))
            {
                break;
            }

            acceptedLength = length;
        }

        return acceptedLength;
    }

    private bool CanPlaceSegment(
        FacetPlan plan,
        PlannedSegment segment,
        bool testAgainstExisting = true)
    {
        if (!RoofFacetDetector.SegmentFits(
            plan.projection,
            segment.center,
            segment.direction,
            segment.length,
            segment.width + objectSeparation,
            11,
            3
        ))
        {
            return false;
        }

        Bounds worldBounds = CalculateWorldBounds(
            plan.projection,
            segment.center,
            segment.direction,
            segment.length,
            segment.width,
            segment.height
        );

        if (IntersectsExclusion(worldBounds))
        {
            return false;
        }

        if (!testAgainstExisting)
        {
            return true;
        }

        foreach (PlannedSegment existing in plan.segments)
        {
            if (SegmentsShareConnection(existing, segment))
            {
                continue;
            }

            Bounds existingBounds = CalculateWorldBounds(
                plan.projection,
                existing.center,
                existing.direction,
                existing.length,
                existing.width + objectSeparation,
                existing.height
            );

            if (existingBounds.Intersects(worldBounds))
            {
                return false;
            }
        }

        return true;
    }

    private static bool SegmentsShareConnection(
        PlannedSegment first,
        PlannedSegment second)
    {
        float threshold = Mathf.Max(
            first.width,
            second.width
        ) * 1.5f;

        return
            Vector2.Distance(first.Start, second.Start) <= threshold ||
            Vector2.Distance(first.Start, second.End) <= threshold ||
            Vector2.Distance(first.End, second.Start) <= threshold ||
            Vector2.Distance(first.End, second.End) <= threshold ||
            DistancePointToSegment(
                second.Start,
                first.Start,
                first.End
            ) <= threshold;
    }

    private bool TryAddTerminal(
        FacetPlan plan,
        Vector2 position,
        Vector2 direction,
        System.Random random)
    {
        Vector3 size = new Vector3(
            Range(
                random,
                equipmentWidthRange.x,
                equipmentWidthRange.y
            ),
            Range(
                random,
                equipmentHeightRange.x,
                equipmentHeightRange.y
            ),
            Range(
                random,
                equipmentLengthRange.x,
                equipmentLengthRange.y
            )
        );

        Vector2 center =
            position + direction * (size.z * 0.5f + 0.25f);

        if (!RoofFacetDetector.SegmentFits(
            plan.projection,
            center,
            direction,
            size.z,
            size.x,
            7,
            3
        ))
        {
            return false;
        }

        Bounds bounds = CalculateWorldBounds(
            plan.projection,
            center,
            direction,
            size.z,
            size.x,
            size.y
        );

        if (IntersectsExclusion(bounds))
        {
            return false;
        }

        PlannedTerminal terminal = new PlannedTerminal
        {
            facetIndex = plan.facetIndex,
            position = center,
            direction = direction,
            type = (TerminalType)random.Next(0, 4),
            size = size,
            rotationJitter = Range(random, -4f, 4f)
        };

        plan.terminals.Add(terminal);
        return true;
    }

    private FacetProjection ResolveFacetProjection(RoofFacet facet)
    {
        RoofFacetDetector.OrientationSettings settings =
            new RoofFacetDetector.OrientationSettings
            {
                snapPrincipalAxisToBoundary =
                    snapPrincipalAxisToBoundary,
                boundarySnapTolerance = boundarySnapTolerance,
                pcaAmbiguityThreshold = pcaAmbiguityThreshold
            };

        return RoofFacetDetector.ResolveProjection(
            facet,
            buildingRoot != null
                ? buildingRoot.transform
                : null,
            orientationMode,
            orientationOffset,
            settings,
            projection =>
            {
                Vector2 size = projection.max - projection.min;
                int fitScore = Mathf.FloorToInt(
                    Mathf.Max(0f, size.x - roofEdgePadding * 2f) /
                    Mathf.Max(primaryDuctWidth, 0.1f)
                );
                return new RoofFacetDetector.ProjectionScore(
                    fitScore,
                    Mathf.RoundToInt(size.x * size.y)
                );
            }
        );
    }

    private void RebuildExclusionBounds()
    {
        exclusionBounds.Clear();

        if (exclusionRoot == null)
        {
            return;
        }

        Renderer[] renderers =
            exclusionRoot.GetComponentsInChildren<Renderer>(true);

        foreach (Renderer renderer in renderers)
        {
            if (
                renderer == null ||
                !renderer.enabled ||
                !renderer.gameObject.activeInHierarchy
            )
            {
                continue;
            }

            Bounds bounds = renderer.bounds;
            bounds.Expand(objectSeparation * 2f);
            exclusionBounds.Add(bounds);
        }
    }

    private bool IntersectsExclusion(Bounds bounds)
    {
        foreach (Bounds exclusion in exclusionBounds)
        {
            if (exclusion.Intersects(bounds))
            {
                return true;
            }
        }

        return false;
    }

    private Bounds CalculateWorldBounds(
        FacetProjection projection,
        Vector2 center,
        Vector2 direction,
        float length,
        float width,
        float height)
    {
        Vector2 perpendicular = new Vector2(
            -direction.y,
            direction.x
        );

        Vector3 worldDirection = (
            projection.u * direction.x +
            projection.v * direction.y
        ).normalized;

        Vector3 worldPerpendicular = (
            projection.u * perpendicular.x +
            projection.v * perpendicular.y
        ).normalized;

        Vector3 worldCenter = projection.ToWorld(center) +
            projection.normal * (
                roofClearance + height * 0.5f
            );

        Vector3 extents =
            Abs(worldDirection) * (length * 0.5f) +
            Abs(worldPerpendicular) * (width * 0.5f) +
            Abs(projection.normal) * (height * 0.5f);

        Bounds bounds = new Bounds(worldCenter, extents * 2f);
        bounds.Expand(objectSeparation * 2f);
        return bounds;
    }

    private void GenerateMechanicalGeometry()
    {
        if (buildingRoot == null)
        {
            EditorUtility.DisplayDialog(
                "Rooftop Mechanical",
                "Assign a building root first.",
                "OK"
            );
            return;
        }

        if (previewDirty || plans.Count == 0)
        {
            BuildPreviewPlan();
        }

        if (plans.Count == 0)
        {
            EditorUtility.DisplayDialog(
                "Rooftop Mechanical",
                "The current settings produced no valid network.",
                "OK"
            );
            return;
        }

        Transform buildingOutput = GetOrCreateOutputFolder();
        if (buildingOutput == null)
        {
            return;
        }

        if (replaceExisting)
        {
            DestroyChildren(buildingOutput);
        }

        int segmentCounter = 0;
        int equipmentCounter = 0;
        int supportCounter = 0;

        foreach (FacetPlan plan in plans)
        {
            Transform facetRoot = FindOrCreateChild(
                buildingOutput,
                string.Format("network_{0:00}", plan.facetIndex)
            );

            Transform ductRoot = FindOrCreateChild(
                facetRoot,
                "ducts"
            );
            Transform pipeRoot = FindOrCreateChild(
                facetRoot,
                "pipes"
            );
            Transform equipmentRoot = FindOrCreateChild(
                facetRoot,
                "equipment"
            );
            Transform supportRoot = FindOrCreateChild(
                facetRoot,
                "supports"
            );

            System.Random random = new System.Random(
                CombineSeed(seed + 173, plan.facetIndex)
            );

            foreach (PlannedSegment segment in plan.segments)
            {
                CreateDuct(
                    plan.projection,
                    segment,
                    ductRoot,
                    segmentCounter++
                );

                if (
                    segment.addPipeBundle &&
                    maximumPipeCount > 0
                )
                {
                    int pipeCount = random.Next(
                        Mathf.Min(minimumPipeCount, maximumPipeCount),
                        maximumPipeCount + 1
                    );
                    CreatePipeBundle(
                        plan.projection,
                        segment,
                        pipeRoot,
                        pipeCount
                    );
                }

                if (generateSupports)
                {
                    supportCounter += CreateSupports(
                        plan.projection,
                        segment,
                        supportRoot,
                        supportCounter
                    );
                }

                foreach (Vector2 junction in segment.childStarts)
                {
                    if (random.NextDouble() <= junctionBoxRate)
                    {
                        CreateJunctionBox(
                            plan.projection,
                            junction,
                            segment,
                            equipmentRoot,
                            equipmentCounter++
                        );
                    }
                }

                if (random.NextDouble() <= ventRate)
                {
                    CreateVentStack(
                        plan.projection,
                        segment.center,
                        equipmentRoot,
                        equipmentCounter++
                    );
                }
            }

            foreach (PlannedTerminal terminal in plan.terminals)
            {
                CreateTerminalEquipment(
                    plan.projection,
                    terminal,
                    equipmentRoot,
                    equipmentCounter++
                );
            }
        }

        EditorSceneManager.MarkSceneDirty(
            buildingRoot.scene
        );
        Selection.activeTransform = buildingOutput;

        Debug.Log(
            string.Format(
                "[Rooftop Mechanical] Generated {0} duct segments, " +
                "{1} equipment objects, and {2} supports under '{3}'.",
                segmentCounter,
                equipmentCounter,
                supportCounter,
                GetPath(buildingOutput)
            ),
            buildingOutput
        );
    }

    private void CreateDuct(
        FacetProjection projection,
        PlannedSegment segment,
        Transform parent,
        int index)
    {
        GameObject duct = CreatePrimitive(
            PrimitiveType.Cube,
            string.Format("duct_{0:000}", index),
            parent,
            ductMaterial
        );

        Vector3 direction = ToWorldDirection(
            projection,
            segment.direction
        );
        Quaternion rotation = Quaternion.LookRotation(
            direction,
            projection.normal
        );
        Vector3 position = projection.ToWorld(segment.center) +
            projection.normal * (
                roofClearance +
                supportHeight +
                segment.height * 0.5f
            );

        duct.transform.SetPositionAndRotation(position, rotation);
        duct.transform.localScale = new Vector3(
            segment.width,
            segment.height,
            segment.length
        );
        ApplyGeneratedFlags(duct);
    }

    private void CreatePipeBundle(
        FacetProjection projection,
        PlannedSegment segment,
        Transform parent,
        int count)
    {
        Vector3 direction = ToWorldDirection(
            projection,
            segment.direction
        );
        Vector3 side = Vector3.Cross(
            projection.normal,
            direction
        ).normalized;

        float bundleWidth =
            count * pipeRadius * 2f +
            Mathf.Max(0, count - 1) * pipeSpacing;

        float startOffset = -bundleWidth * 0.5f + pipeRadius;

        for (int pipeIndex = 0;
            pipeIndex < count;
            pipeIndex++)
        {
            float sideOffset =
                startOffset +
                pipeIndex * (pipeRadius * 2f + pipeSpacing);

            Vector3 center = projection.ToWorld(segment.center) +
                side * (
                    segment.width * 0.75f +
                    sideOffset
                ) +
                projection.normal * (
                    roofClearance +
                    supportHeight +
                    pipeRadius * 1.8f
                );

            CreateCylinderBetween(
                string.Format(
                    "pipe_{0:000}_{1:00}",
                    segment.index,
                    pipeIndex
                ),
                center - direction * segment.length * 0.46f,
                center + direction * segment.length * 0.46f,
                pipeRadius,
                parent,
                pipeMaterial
            );
        }
    }

    private int CreateSupports(
        FacetProjection projection,
        PlannedSegment segment,
        Transform parent,
        int startIndex)
    {
        int supportCount = Mathf.Max(
            2,
            Mathf.CeilToInt(
                segment.length /
                Mathf.Max(supportSpacing, 0.5f)
            ) + 1
        );

        Vector3 direction = ToWorldDirection(
            projection,
            segment.direction
        );

        for (int index = 0; index < supportCount; index++)
        {
            float t = supportCount <= 1
                ? 0.5f
                : index / (float)(supportCount - 1);

            Vector2 point = Vector2.Lerp(
                segment.Start,
                segment.End,
                t
            );

            GameObject support = CreatePrimitive(
                PrimitiveType.Cube,
                string.Format(
                    "support_{0:000}",
                    startIndex + index
                ),
                parent,
                supportMaterial
            );

            Quaternion rotation = Quaternion.LookRotation(
                direction,
                projection.normal
            );

            Vector3 position = projection.ToWorld(point) +
                projection.normal * (
                    roofClearance + supportHeight * 0.5f
                );

            support.transform.SetPositionAndRotation(
                position,
                rotation
            );
            support.transform.localScale = new Vector3(
                segment.width * 1.25f,
                supportHeight,
                supportThickness
            );
            ApplyGeneratedFlags(support);
        }

        return supportCount;
    }

    private void CreateJunctionBox(
        FacetProjection projection,
        Vector2 point,
        PlannedSegment segment,
        Transform parent,
        int index)
    {
        GameObject box = CreatePrimitive(
            PrimitiveType.Cube,
            string.Format("junction_{0:000}", index),
            parent,
            equipmentMaterial
        );

        Vector3 direction = ToWorldDirection(
            projection,
            segment.direction
        );
        Quaternion rotation = Quaternion.LookRotation(
            direction,
            projection.normal
        );

        float size = Mathf.Max(segment.width * 1.35f, 0.45f);
        Vector3 position = projection.ToWorld(point) +
            projection.normal * (
                roofClearance +
                supportHeight +
                segment.height * 0.58f
            );

        box.transform.SetPositionAndRotation(position, rotation);
        box.transform.localScale = new Vector3(
            size,
            segment.height * 1.15f,
            size
        );
        ApplyGeneratedFlags(box);
    }

    private void CreateVentStack(
        FacetProjection projection,
        Vector2 point,
        Transform parent,
        int index)
    {
        Vector3 basePosition = projection.ToWorld(point) +
            projection.normal * roofClearance;

        int count = 2 + Mathf.Abs(index % 3);
        for (int vent = 0; vent < count; vent++)
        {
            Vector3 offset =
                projection.u * ((vent - (count - 1) * 0.5f) * 0.45f);

            Vector3 start = basePosition + offset;
            Vector3 end = start +
                projection.normal * (0.8f + vent * 0.16f);

            CreateCylinderBetween(
                string.Format("vent_{0:000}_{1:00}", index, vent),
                start,
                end,
                pipeRadius * 1.35f,
                parent,
                pipeMaterial
            );
        }
    }

    private void CreateTerminalEquipment(
        FacetProjection projection,
        PlannedTerminal terminal,
        Transform parent,
        int index)
    {
        switch (terminal.type)
        {
            case TerminalType.FanHousing:
                CreateFanHousing(
                    projection,
                    terminal,
                    parent,
                    index
                );
                break;

            case TerminalType.VentCluster:
                CreateTerminalVentCluster(
                    projection,
                    terminal,
                    parent,
                    index
                );
                break;

            case TerminalType.PipeManifold:
                CreateTerminalPipeManifold(
                    projection,
                    terminal,
                    parent,
                    index
                );
                break;

            default:
                CreateAirHandlingUnit(
                    projection,
                    terminal,
                    parent,
                    index
                );
                break;
        }
    }

    private void CreateAirHandlingUnit(
        FacetProjection projection,
        PlannedTerminal terminal,
        Transform parent,
        int index)
    {
        Transform root = FindOrCreateChild(
            parent,
            string.Format("ahu_{0:000}", index)
        );

        Vector3 direction = ToWorldDirection(
            projection,
            terminal.direction
        );
        Quaternion rotation = Quaternion.LookRotation(
            direction,
            projection.normal
        ) * Quaternion.AngleAxis(
            terminal.rotationJitter,
            projection.normal
        );

        Vector3 basePosition =
            projection.ToWorld(terminal.position) +
            projection.normal * (
                roofClearance + supportHeight
            );

        GameObject body = CreatePrimitive(
            PrimitiveType.Cube,
            "body",
            root,
            equipmentMaterial
        );
        body.transform.SetPositionAndRotation(
            basePosition +
                projection.normal * (terminal.size.y * 0.5f),
            rotation
        );
        body.transform.localScale = terminal.size;
        ApplyGeneratedFlags(body);

        GameObject cap = CreatePrimitive(
            PrimitiveType.Cube,
            "service_cap",
            root,
            supportMaterial
        );
        cap.transform.SetPositionAndRotation(
            basePosition +
                projection.normal * (terminal.size.y + 0.12f),
            rotation
        );
        cap.transform.localScale = new Vector3(
            terminal.size.x * 0.78f,
            0.18f,
            terminal.size.z * 0.56f
        );
        ApplyGeneratedFlags(cap);
    }

    private void CreateFanHousing(
        FacetProjection projection,
        PlannedTerminal terminal,
        Transform parent,
        int index)
    {
        Transform root = FindOrCreateChild(
            parent,
            string.Format("fan_{0:000}", index)
        );

        Vector3 direction = ToWorldDirection(
            projection,
            terminal.direction
        );
        Quaternion rotation = Quaternion.LookRotation(
            direction,
            projection.normal
        );
        Vector3 center = projection.ToWorld(terminal.position) +
            projection.normal * (
                roofClearance +
                supportHeight +
                terminal.size.y * 0.5f
            );

        GameObject housing = CreatePrimitive(
            PrimitiveType.Cube,
            "housing",
            root,
            equipmentMaterial
        );
        housing.transform.SetPositionAndRotation(center, rotation);
        housing.transform.localScale = new Vector3(
            terminal.size.x,
            terminal.size.y,
            terminal.size.z
        );
        ApplyGeneratedFlags(housing);

        float fanRadius = Mathf.Min(
            terminal.size.x,
            terminal.size.z
        ) * 0.28f;

        Vector3 fanStart = center +
            projection.normal * (terminal.size.y * 0.48f);
        Vector3 fanEnd = fanStart +
            projection.normal * 0.22f;

        CreateCylinderBetween(
            "fan_top",
            fanStart,
            fanEnd,
            fanRadius,
            root,
            supportMaterial
        );
    }

    private void CreateTerminalVentCluster(
        FacetProjection projection,
        PlannedTerminal terminal,
        Transform parent,
        int index)
    {
        Transform root = FindOrCreateChild(
            parent,
            string.Format("vent_cluster_{0:000}", index)
        );

        Vector3 center = projection.ToWorld(terminal.position) +
            projection.normal * roofClearance;

        for (int row = 0; row < 2; row++)
        {
            for (int column = 0; column < 3; column++)
            {
                Vector3 offset =
                    projection.u * ((column - 1f) * 0.55f) +
                    projection.v * ((row - 0.5f) * 0.55f);

                Vector3 start = center + offset;
                Vector3 end = start +
                    projection.normal * (
                        terminal.size.y *
                        (0.55f + 0.08f * (row + column))
                    );

                CreateCylinderBetween(
                    string.Format("stack_{0}_{1}", row, column),
                    start,
                    end,
                    pipeRadius * 1.4f,
                    root,
                    pipeMaterial
                );
            }
        }
    }

    private void CreateTerminalPipeManifold(
        FacetProjection projection,
        PlannedTerminal terminal,
        Transform parent,
        int index)
    {
        Transform root = FindOrCreateChild(
            parent,
            string.Format("manifold_{0:000}", index)
        );

        Vector3 direction = ToWorldDirection(
            projection,
            terminal.direction
        );
        Vector3 side = Vector3.Cross(
            projection.normal,
            direction
        ).normalized;
        Vector3 center = projection.ToWorld(terminal.position) +
            projection.normal * (
                roofClearance + supportHeight + pipeRadius * 2f
            );

        int count = Mathf.Clamp(maximumPipeCount, 2, 6);
        for (int pipe = 0; pipe < count; pipe++)
        {
            float offset =
                (pipe - (count - 1) * 0.5f) *
                (pipeRadius * 2f + pipeSpacing);

            Vector3 pipeCenter = center + side * offset;
            CreateCylinderBetween(
                string.Format("pipe_{0:00}", pipe),
                pipeCenter -
                    direction * terminal.size.z * 0.45f,
                pipeCenter +
                    direction * terminal.size.z * 0.45f,
                pipeRadius,
                root,
                pipeMaterial
            );
        }

        GameObject header = CreatePrimitive(
            PrimitiveType.Cube,
            "header",
            root,
            equipmentMaterial
        );
        header.transform.SetPositionAndRotation(
            center + direction * terminal.size.z * 0.42f,
            Quaternion.LookRotation(
                side,
                projection.normal
            )
        );
        header.transform.localScale = new Vector3(
            pipeRadius * 3f,
            pipeRadius * 3f,
            terminal.size.x
        );
        ApplyGeneratedFlags(header);
    }

    private GameObject CreatePrimitive(
        PrimitiveType primitiveType,
        string name,
        Transform parent,
        Material material)
    {
        GameObject generated = GameObject.CreatePrimitive(primitiveType);
        generated.name = name;
        Undo.RegisterCreatedObjectUndo(
            generated,
            "Generate Rooftop Mechanical"
        );
        generated.transform.SetParent(parent, true);

        Renderer renderer = generated.GetComponent<Renderer>();
        if (renderer != null && material != null)
        {
            renderer.sharedMaterial = material;
        }

        if (removePrimitiveColliders)
        {
            Collider collider = generated.GetComponent<Collider>();
            if (collider != null)
            {
                DestroyImmediate(collider);
            }
        }

        return generated;
    }

    private void CreateCylinderBetween(
        string name,
        Vector3 start,
        Vector3 end,
        float radius,
        Transform parent,
        Material material)
    {
        Vector3 delta = end - start;
        float length = delta.magnitude;
        if (length <= 0.0001f)
        {
            return;
        }

        GameObject cylinder = CreatePrimitive(
            PrimitiveType.Cylinder,
            name,
            parent,
            material
        );

        cylinder.transform.position = (start + end) * 0.5f;
        cylinder.transform.rotation = Quaternion.FromToRotation(
            Vector3.up,
            delta / length
        );
        cylinder.transform.localScale = new Vector3(
            radius,
            length * 0.5f,
            radius
        );
        ApplyGeneratedFlags(cylinder);
    }

    private void ApplyGeneratedFlags(GameObject generated)
    {
        if (generated == null)
        {
            return;
        }

        if (markGeneratedStatic)
        {
            GameObjectUtility.SetStaticEditorFlags(
                generated,
                StaticEditorFlags.BatchingStatic |
                StaticEditorFlags.ContributeGI |
                StaticEditorFlags.ReflectionProbeStatic
            );
        }
    }

    private void BuildPreviewLines(
        FacetPlan plan,
        RoofFacet facet)
    {
        plan.boundaryLines = new Vector3[
            facet.boundaryLineSegments.Count
        ];

        for (int index = 0;
            index < facet.boundaryLineSegments.Count;
            index++)
        {
            plan.boundaryLines[index] =
                facet.boundaryLineSegments[index] +
                facet.normal * 0.08f;
        }

        List<Vector3> segmentLines = new List<Vector3>();
        foreach (PlannedSegment segment in plan.segments)
        {
            AddSegmentRectangleLines(
                segmentLines,
                plan.projection,
                segment.center,
                segment.direction,
                segment.length,
                segment.width,
                0.16f
            );
        }
        plan.segmentLines = segmentLines.ToArray();

        List<Vector3> terminalLines = new List<Vector3>();
        foreach (PlannedTerminal terminal in plan.terminals)
        {
            AddSegmentRectangleLines(
                terminalLines,
                plan.projection,
                terminal.position,
                terminal.direction,
                terminal.size.z,
                terminal.size.x,
                0.2f
            );
        }
        plan.terminalLines = terminalLines.ToArray();
    }

    private static void AddSegmentRectangleLines(
        List<Vector3> lines,
        FacetProjection projection,
        Vector2 center,
        Vector2 direction,
        float length,
        float width,
        float heightOffset)
    {
        Vector2 side = new Vector2(-direction.y, direction.x);
        Vector2 halfForward = direction.normalized * length * 0.5f;
        Vector2 halfSide = side.normalized * width * 0.5f;

        Vector2 p0 = center - halfForward - halfSide;
        Vector2 p1 = center + halfForward - halfSide;
        Vector2 p2 = center + halfForward + halfSide;
        Vector2 p3 = center - halfForward + halfSide;

        Vector3 offset = projection.normal * heightOffset;
        Vector3 w0 = projection.ToWorld(p0) + offset;
        Vector3 w1 = projection.ToWorld(p1) + offset;
        Vector3 w2 = projection.ToWorld(p2) + offset;
        Vector3 w3 = projection.ToWorld(p3) + offset;

        lines.Add(w0); lines.Add(w1);
        lines.Add(w1); lines.Add(w2);
        lines.Add(w2); lines.Add(w3);
        lines.Add(w3); lines.Add(w0);
    }

    private void DrawScenePreview(SceneView sceneView)
    {
        if (facets.Count == 0)
        {
            return;
        }

        Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;

        if (showDetectedFacets)
        {
            for (int index = 0; index < facets.Count; index++)
            {
                RoofFacet facet = facets[index];
                if (!facet.enabled)
                {
                    continue;
                }

                Handles.color = GetFacetColor(index, 0.82f);
                Vector3[] lines = new Vector3[
                    facet.boundaryLineSegments.Count
                ];

                for (int line = 0;
                    line < facet.boundaryLineSegments.Count;
                    line++)
                {
                    lines[line] =
                        facet.boundaryLineSegments[line] +
                        facet.normal * 0.06f;
                }

                if (lines.Length >= 2)
                {
                    Handles.DrawLines(lines);
                }

                if (showFacetLabels)
                {
                    Handles.Label(
                        facet.center + facet.normal * 0.6f,
                        string.Format(
                            "Roof {0:00}\n{1:F1} m² · {2:F1}°",
                            index,
                            facet.area,
                            facet.Slope
                        )
                    );
                }
            }
        }

        if (previewDirty)
        {
            return;
        }

        foreach (FacetPlan plan in plans)
        {
            if (showNetworkPreview && plan.segmentLines.Length > 0)
            {
                Handles.color = new Color(0.25f, 0.9f, 1f, 0.95f);
                Handles.DrawLines(plan.segmentLines);
            }

            if (showTerminalPreview && plan.terminalLines.Length > 0)
            {
                Handles.color = new Color(1f, 0.62f, 0.18f, 0.95f);
                Handles.DrawLines(plan.terminalLines);
            }
        }
    }

    private void LogDetectedFacets()
    {
        Debug.Log(
            string.Format(
                "[Rooftop Mechanical] Building '{0}'\n" +
                "Bounds center {1}, size {2}\n" +
                "Scanned {3:N0}; accepted {4:N0}; facets {5}",
                buildingRoot.name,
                buildingBounds.center,
                buildingBounds.size,
                scannedTriangles,
                acceptedTriangles,
                facets.Count
            ),
            buildingRoot
        );
    }

    private Transform GetOrCreateOutputFolder()
    {
        if (siteRoot == null)
        {
            siteRoot = FindLikelySiteRoot(buildingRoot.transform);
        }

        if (siteRoot == null)
        {
            EditorUtility.DisplayDialog(
                "Rooftop Mechanical",
                "Assign a site root.",
                "OK"
            );
            return null;
        }

        Transform outputRoot = FindOrCreateChild(
            siteRoot.transform,
            SafeName(outputRootName, "rooftop_mechanical")
        );

        string resolvedBuildingName =
            string.IsNullOrWhiteSpace(buildingFolderName)
                ? buildingRoot.name
                : buildingFolderName.Trim();

        return FindOrCreateChild(
            outputRoot,
            resolvedBuildingName
        );
    }

    private Transform FindOutputFolder()
    {
        if (siteRoot == null || buildingRoot == null)
        {
            return null;
        }

        Transform outputRoot = FindChild(
            siteRoot.transform,
            SafeName(outputRootName, "rooftop_mechanical")
        );

        if (outputRoot == null)
        {
            return null;
        }

        string resolvedBuildingName =
            string.IsNullOrWhiteSpace(buildingFolderName)
                ? buildingRoot.name
                : buildingFolderName.Trim();

        return FindChild(outputRoot, resolvedBuildingName);
    }

    private void ClearGeneratedMechanical()
    {
        Transform output = FindOutputFolder();
        if (output == null)
        {
            return;
        }

        Undo.DestroyObjectImmediate(output.gameObject);
        EditorSceneManager.MarkSceneDirty(buildingRoot.scene);
    }

    private static void DestroyChildren(Transform parent)
    {
        for (int index = parent.childCount - 1;
            index >= 0;
            index--)
        {
            Undo.DestroyObjectImmediate(
                parent.GetChild(index).gameObject
            );
        }
    }

    private static Transform FindOrCreateChild(
        Transform parent,
        string name)
    {
        Transform child = FindChild(parent, name);
        if (child != null)
        {
            return child;
        }

        GameObject created = new GameObject(name);
        Undo.RegisterCreatedObjectUndo(
            created,
            "Create Rooftop Mechanical Folder"
        );
        created.transform.SetParent(parent, false);
        return created.transform;
    }

    private static Transform FindChild(
        Transform parent,
        string name)
    {
        for (int index = 0; index < parent.childCount; index++)
        {
            Transform child = parent.GetChild(index);
            if (child.name == name)
            {
                return child;
            }
        }

        return null;
    }

    private static GameObject FindLikelySiteRoot(Transform building)
    {
        if (building == null)
        {
            return null;
        }

        Transform cursor = building;
        GameObject last = building.gameObject;

        while (cursor.parent != null)
        {
            cursor = cursor.parent;
            last = cursor.gameObject;

            if (
                cursor.name.IndexOf(
                    "cib_site",
                    StringComparison.OrdinalIgnoreCase
                ) >= 0
            )
            {
                return cursor.gameObject;
            }
        }

        return last;
    }

    private static string SafeName(
        string value,
        string fallback)
    {
        return string.IsNullOrWhiteSpace(value)
            ? fallback
            : value.Trim();
    }

    private static Vector3 ToWorldDirection(
        FacetProjection projection,
        Vector2 direction)
    {
        return (
            projection.u * direction.x +
            projection.v * direction.y
        ).normalized;
    }

    private static Vector2 Rotate2D(
        Vector2 value,
        float angleDegrees)
    {
        float radians = angleDegrees * Mathf.Deg2Rad;
        float cosine = Mathf.Cos(radians);
        float sine = Mathf.Sin(radians);

        return new Vector2(
            value.x * cosine - value.y * sine,
            value.x * sine + value.y * cosine
        );
    }

    private static float DistancePointToSegment(
        Vector2 point,
        Vector2 start,
        Vector2 end)
    {
        Vector2 segment = end - start;
        float denominator = segment.sqrMagnitude;

        if (denominator <= 0.000001f)
        {
            return Vector2.Distance(point, start);
        }

        float t = Mathf.Clamp01(
            Vector2.Dot(point - start, segment) /
            denominator
        );

        return Vector2.Distance(
            point,
            start + segment * t
        );
    }

    private static float Range(
        System.Random random,
        float minimum,
        float maximum)
    {
        if (maximum < minimum)
        {
            float temporary = minimum;
            minimum = maximum;
            maximum = temporary;
        }

        return Mathf.Lerp(
            minimum,
            maximum,
            (float)random.NextDouble()
        );
    }

    private static int CombineSeed(int first, int second)
    {
        unchecked
        {
            return first * 486187739 + second * 16777619;
        }
    }

    private static Vector3 Abs(Vector3 value)
    {
        return new Vector3(
            Mathf.Abs(value.x),
            Mathf.Abs(value.y),
            Mathf.Abs(value.z)
        );
    }

    private static Color GetFacetColor(int index, float alpha)
    {
        float hue = Mathf.Repeat(index * 0.173f, 1f);
        Color color = Color.HSVToRGB(hue, 0.72f, 1f);
        color.a = alpha;
        return color;
    }

    private static string GetPath(Transform transform)
    {
        if (transform == null)
        {
            return "<null>";
        }

        string path = transform.name;
        Transform cursor = transform.parent;

        while (cursor != null)
        {
            path = cursor.name + "/" + path;
            cursor = cursor.parent;
        }

        return path;
    }
}

#endif
