ROOFTOP PROCEDURAL TOOLKIT
==========================

Files
-----

Editor/RoofFacetDetector.cs
    Shared generic roof detector and geometric projection utility.

Editor/SolarPanelRoofGeneratorV4Window.cs
    Refactored version of the V3 solar-panel tool. It retains the V3 layout,
    group, hierarchy, preview-cache, orientation, and prefab features while
    delegating roof detection, boundary analysis, projection, bounds, and
    footprint testing to RoofFacetDetector.

Editor/RooftopMechanicalGeneratorWindow.cs
    Editor generator for deterministic roof-aligned ducts, branches, pipe
    bundles, supports, junction boxes, vents, and terminal machinery.

Installation
------------

Place all three files together in an Editor folder, for example:

Assets/
└── Editor/
    └── RooftopProcedural/
        ├── RoofFacetDetector.cs
        ├── SolarPanelRoofGeneratorV4Window.cs
        └── RooftopMechanicalGeneratorWindow.cs

Menus
-----

Tools → IFC Dashboard → Solar Panel Roof Generator V4 (Shared Detector)
Tools → IFC Dashboard → Rooftop Mechanical Generator

Mechanical-generator first test
-------------------------------

1. Assign Site Root and an X-shaped Building Root.
2. Optionally assign roof_panels or the relevant building's panel folder as
   Exclusion Root.
3. Assign four shared materials. Missing materials are allowed; Unity's
   default material will be used for those categories.
4. Detect Roof Facets.
5. Disable facets that should stay clear.
6. Build / Refresh Preview.
7. Generate Rooftop Mechanical.

Suggested starting values
-------------------------

Primary Spine Count:       1
Maximum Recursion Depth:   2
Branch Probability:        0.45–0.55
Branch Spacing:            6–8
Primary Duct Width:        1.0–1.4
Primary Duct Height:       0.7–1.0
Roof Edge Padding:         1.0–1.8
Terminal Equipment Rate:  0.65–0.80
Pipe Bundle Rate:          0.25–0.45
Vent Rate:                 0.15–0.30

The generator is deterministic for a given building, facet order, seed, and
settings. Change Seed to produce another arrangement.

Output hierarchy
----------------

cib_site/
└── rooftop_mechanical/
    └── BuildingName/
        └── network_00/
            ├── ducts/
            ├── pipes/
            ├── equipment/
            └── supports/

Notes
-----

- The tools are editor-only and add no procedural runtime cost to WebGL.
- Primitive colliders are removed by default.
- Repeated geometry shares the assigned materials.
- The mechanical generator uses ordinary Unity primitives. Cylinders are
  suitable for a proof of concept; a later pass can replace them with a
  custom low-poly pipe mesh if draw-call or triangle budgets require it.
- Unity's compiler remains the definitive compatibility check for the exact
  project and package versions.
