SITE-WIDE TEMPERATURE BRIDGE
============================

This version changes the website API from:

    UpdateTemperature(buildingID, value)

to:

    SetTemperature(value)

The value now represents the entire site and is displayed immediately in
the bottom-right Unity temperature UI.


FILES TO REPLACE
----------------

Assets/Scripts/Web/WebGLDashboardBridge.cs

Assets/Plugins/WebGL/FutureDecisionsDashboard.jslib

Assets/WebGLTemplates/FutureDecisions/index.html


UNITY TEMPERATURE BUTTON SETUP
------------------------------

1. Select the bottom-right temperature TextMeshPro UI object.

2. Add a Button component to that same GameObject.

   TextMeshProUGUI inherits from Unity Graphic, so the text can act as the
   Button's target graphic.

3. On the TMP component:

       Raycast Target: On

4. Confirm the parent Canvas has:

       Graphic Raycaster: enabled

5. Confirm the scene has an EventSystem.

6. On WebGLBridge / WebGLDashboardBridge assign:

       Temperature Text:
           the temperature TMP object

       Temperature Button:
           the Button added to that object

The bridge also tries to find the Button automatically on the assigned TMP
GameObject, but assigning it explicitly is clearer.

Set the Button's Transition to None if you do not want clicking or hovering
to alter the text colour.


WEBSITE API
-----------

External JavaScript can now call:

    SetTemperature(21.5);

The form below the Unity canvas calls the same function.

Before Unity finishes loading, only the most recent requested site
temperature is retained and sent after initialization.


UNITY TO WEBSITE
----------------

Building selection still calls:

    window.onUnityBuildingClicked(
        buildingID,
        displayName,
        websiteRoute
    );

Clicking the Unity temperature UI calls:

    window.onUnityTemperatureClicked(
        formattedTemperature
    );

The supplied index.html displays a browser alert for both callbacks.


EDITOR TESTING
--------------

In the Unity Editor, the temperature button prints a simulation message to
the Console. Browser alerts are only available in a Web build.
